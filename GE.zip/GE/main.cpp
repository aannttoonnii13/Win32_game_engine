#include "main_skeleton.h"

//-----------------------------------------------------------------
// Funkcje silnika
//-----------------------------------------------------------------

Tengine *  _pGame;

BOOL GameInitialize(HINSTANCE hInstance)
{
	
	// Tworzymy silnik gry
	_pGame = new Tengine(hInstance, TEXT("ENGINE"), TEXT("ENGINE"), IDI_SKELETON, IDI_SKELETON_SM, 640, 480);
	
	if (_pGame == NULL)
	{
	
		return FALSE;
	
	}
	
	// Ustawiamy FPS
	_pGame->SetFrameRate(15);

	return TRUE;

}

void GameStart(HWND hWindow)
{
	
	// Ustawiamy pocz�tek generatora liczb losowych
	srand(GetTickCount());

}

void GameEnd()
{
	
	// Usuwamy silnik
	delete _pGame;

}

void GameActivate(HWND hWindow)
{
	
	HDC hDC;
	RECT rect;

	// Piszemy na ekranie tekst aktywacyjny
	GetClientRect(hWindow, &rect);
	hDC = GetDC(hWindow);
	DrawText(hDC, TEXT("Activated!"), -1, &rect,
	DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	ReleaseDC(hWindow, hDC);

}

void GameDeactivate(HWND hWindow)
{
	
	HDC hDC;
	RECT rect;

	// Rysujemy ekran dysaktywacji
	GetClientRect(hWindow, &rect);
	hDC = GetDC(hWindow);
	DrawText(hDC, TEXT("Deactivated!"), -1, &rect,
	DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	ReleaseDC(hWindow, hDC);

}

void GamePaint(HDC hDC)
{
}

void GameCycle()
{
	
	//HWND hWindow = _pGame->GetWindow();

	//HDC hDC = GetDC(hWindow);

		//Rectangle( hDC, 10, 10, 100, 100 );
		//DrawIcon(hDC, rand() % _pGame->GetWidth(), rand() % _pGame->GetHeight(), (HICON)(WORD)GetClassLong(hWindow, IDI_SKELETON));

	//ReleaseDC(hWindow, hDC);

}
