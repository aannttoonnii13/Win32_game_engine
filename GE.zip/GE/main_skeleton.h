#include "main_header.h"

//-----------------------------------------------------------------
// Funkcje globalne
//-----------------------------------------------------------------

LRESULT CALLBACK WndProc(HWND hWindow, UINT msg, WPARAM wParam, LPARAM lParam);

//-----------------------------------------------------------------
// Funkcje silnika
//-----------------------------------------------------------------

BOOL GameInitialize(HINSTANCE hInstance);
void GameStart(HWND hWindow);
void GameEnd();
void GameActivate(HWND hWindow);
void GameDeactivate(HWND hWindow);
void GamePaint(HDC hDC);
void GameCycle();

//-----------------------------------------------------------------
// Definicje funkcji globalnych
//-----------------------------------------------------------------

class Tengine
{
	
	protected:
		
		// Zmienne wewn�trzne
		HINSTANCE m_hInstance;
		HWND m_hWindow;
		TCHAR m_szWindowClass[32];
		TCHAR m_szTitle[32];
		WORD m_wIcon, m_wSmallIcon;
		int m_iWidth, m_iHeight;
		int m_iFrameDelay;
		BOOL m_bSleep;
		
	public:
		
		//zmienne zewn�trzne
		static Tengine *m_pEngine;
		
		// Konstruktor i destruktor(wirtualny)
		Tengine(HINSTANCE, LPTSTR, LPTSTR, WORD, WORD, int, int);
		virtual ~Tengine();
		
		// Metody g��wne
		static Tengine* GetEngine()
		{
		
			return m_pEngine;
		
		}
		
		BOOL Initialize(int iCmdShow);
		LRESULT HandleEvent(HWND hWindow, UINT msg, WPARAM wParam, LPARAM lParam);
		
		// Metody dost�pu do silnika
		HINSTANCE GetInstance()
		{ 
			return m_hInstance; 
		}
		
		HWND GetWindow()
		{
			return m_hWindow;
		}
		
		void SetWindow(HWND hWindow)
		{
			m_hWindow = hWindow;
		}
		
		LPTSTR GetTitle()
		{
			return m_szTitle;
		}
		
		WORD GetIcon()
		{
			return m_wIcon;
		}
		
		WORD GetSmallIcon()
		{
			return m_wSmallIcon;
		}
		
		int GetWidth()
		{
			return m_iWidth;
		}
		
		int GetHeight()
		{
			return m_iHeight;
		}
		
		int GetFrameDelay()
		{
			return m_iFrameDelay;
		}
		
		void SetFrameRate(int iFrameRate)
		{
			m_iFrameDelay = 1000 / iFrameRate;
		}
		
		BOOL GetSleep()
		{
			return m_bSleep;
		}
		
		void SetSleep(BOOL bSleep)
		{
			m_bSleep = bSleep;
		}
	
};

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	
	MSG msg;
	static int iTickTrigger = 0;
	int iTickCount;
	
	if( GameInitialize(hInstance) )
	{
		
		//Inicjacja silnika
		if (!Tengine::GetEngine()->Initialize(iCmdShow))
		{
			
			return FALSE;
			
		}
		
		for(;;)
		{
			
			if ( PeekMessage(&msg, NULL, 0, 0, PM_REMOVE) )
			{
				
				// Przetwarzanie wiadomo�ci
				if (msg.message == WM_QUIT)
				{
					
					break;
					
				}
				
				TranslateMessage(&msg);
				DispatchMessage(&msg);
				
			}
			else
			{
				
				// P�tla g��wna
				if (!Tengine::GetEngine()->GetSleep())
				{
					
					// Sprawdzamy ticki
					iTickCount = GetTickCount();
					
					if (iTickCount > iTickTrigger)
					{
						iTickTrigger = iTickCount+Tengine::GetEngine()->GetFrameDelay();
						GameCycle();
					}
					
				}
				
			}
			
		}
		
		//Zwracamy wiadomo�� spowrotem do systemu
		return (int) msg.wParam;
		
	}
	
	GameEnd();

	return TRUE;
	
}

LRESULT CALLBACK WndProc(HWND hWindow, UINT msg, WPARAM wParam, LPARAM lParam)
{
	
	//Wszystkie wiadomo�ci od windowsa wrzucamy do funkcji HandleEvent
	return Tengine::GetEngine()->HandleEvent(hWindow, msg, wParam, lParam);
	
}

//Definicja konstruktora silnika
Tengine::Tengine(HINSTANCE hInstance, LPTSTR szWindowClass, LPTSTR szTitle, WORD wIcon, WORD wSmallIcon, int iWidth, int iHeight)
{
	
	// No to ustawiamy :)
	m_pEngine = this; //Wska�nik na silnik
	m_hInstance = hInstance; //Uchwyt do programu
	m_hWindow = NULL; //Okienko b�dzie NULL
	
	if (lstrlen(szWindowClass) > 0) //Jak klasa naszego programu to nie NULL
	{
		
		lstrcpy(m_szWindowClass, szWindowClass); //To ustawiamy klas� silnika na tak� sam�
		
	}
	
	if (lstrlen(szTitle) > 0) //Jak mamy tytu�
	{
	
		lstrcpy(m_szTitle, szTitle); //to go kopiujemy
	
	}
	
	m_wIcon = wIcon; //Bitmapa du�ej ikonki (tej na pasku zada�)
	m_wSmallIcon = wSmallIcon; //Bitmapa ma�ej ikonki (na pasku na g�rze)
	m_iWidth = iWidth; //Szeroko�� okienka
	m_iHeight = iHeight; //Wysoko�� okienka
	m_iFrameDelay = 50; //1000/50=20 FPS domy�lnie
	m_bSleep = TRUE; //Silnik �pi...

}

//Destruktor b�dzie pusty...
Tengine::~ETengine()
{
}

//funkcja inicjuj�ca silnik
BOOL Tengine::Initialize(int iCmdShow)
{
	
	WNDCLASSEX wndclass;

	// Parametry okna
	wndclass.cbSize = sizeof(wndclass);
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = m_hInstance;
	wndclass.hIcon = LoadIcon(m_hInstance, MAKEINTRESOURCE(GetIcon()));
	wndclass.hIconSm = LoadIcon(m_hInstance, MAKEINTRESOURCE(GetSmallIcon()));
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = m_szWindowClass;
	
	

	// Rejestrujemy klas� okna
	if ( !RegisterClassEx(&wndclass) )
	{
		
		return FALSE;
	
	}

	// 	liczymy rozmiar okna i jego pozycj� na podstawie rozmiaru gry
	int iWindowWidth=m_iWidth+GetSystemMetrics(SM_CXFIXEDFRAME)*2, iWindowHeight=m_iHeight+GetSystemMetrics(SM_CYFIXEDFRAME)*2+GetSystemMetrics(SM_CYCAPTION);
	
	if (wndclass.lpszMenuName != NULL)
	{
		
		iWindowHeight += GetSystemMetrics(SM_CYMENU);
		
	}
	
	int iXWindowPos = (GetSystemMetrics(SM_CXSCREEN) - iWindowWidth) / 2, iYWindowPos = (GetSystemMetrics(SM_CYSCREEN) - iWindowHeight) / 2;

	// 	Tworzymy okienko
	m_hWindow = CreateWindow(m_szWindowClass, m_szTitle, WS_POPUPWINDOW | WS_CAPTION | WS_MINIMIZEBOX | WS_MAXIMIZEBOX, iXWindowPos, iYWindowPos, iWindowWidth, iWindowHeight, NULL, NULL, m_hInstance, NULL);
	
	if (!m_hWindow)
	{
	
		return FALSE;
	
	}

	// Pokazujemy i od�wie�amy okno
	ShowWindow(m_hWindow, iCmdShow);
	UpdateWindow(m_hWindow);

	return TRUE;

}

//Tu przekierowywujemy wszystko z p�tli komunikat�w
LRESULT Tengine::HandleEvent(HWND hWindow, UINT msg, WPARAM wParam, LPARAM lParam)
{
	
	// Sortujemy poczt� :)
	switch (msg)
	{
		
		case WM_CREATE:
			
		// Ustawiamy okno i zaczynamy gr�
		SetWindow(hWindow);
		GameStart(hWindow);
		
		return 0;
		
		case WM_ACTIVATE:
			
			// Aktywujemy/Dysaktywujemy gr�
			if (wParam != WA_INACTIVE)
			{
				GameActivate(hWindow);
				SetSleep(FALSE);
			}
			else
			{
				GameDeactivate(hWindow);
				SetSleep(TRUE);
			}
		
		return 0;
		
		case WM_PAINT:
			
			HDC hDC;
			PAINTSTRUCT ps;
			hDC = BeginPaint(hWindow, &ps);
		
			// Rysujemy gr�
			GamePaint(hDC);
	
			EndPaint(hWindow, &ps);
		
		return 0;

		case WM_DESTROY:
			
			// Ko�czymy gr� i zamykamy program
			GameEnd();
			PostQuitMessage(0);
		
		return 0;
		
		default:
		return DefWindowProc(hWindow, msg, wParam, lParam);
		
	}

}
